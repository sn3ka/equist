var stage;
(function () {
  'use strict';

  let canvas, exportRoot;
  let initialized = false;

  function initLoader() {
    if (initialized) return;
    initialized = true;

    canvas = document.getElementById('canvas');
    const container = document.getElementById('animation_container');

    if (!canvas || typeof AdobeAn === 'undefined') {
      console.warn('Loader: Canvas or AdobeAn not ready');
      return;
    }

    const comp = AdobeAn.getComposition('C33273F3D3424240968998591D1D8A37');
    const lib = comp.getLibrary();

    exportRoot = new lib.E_loading_white_2();

    // IMPORTANT: stage must be global
    stage = new lib.Stage(canvas);

    stage.addChild(exportRoot);

    createjs.Ticker.framerate = lib.properties.fps;
    createjs.Ticker.addEventListener('tick', stage);

    AdobeAn.makeResponsive(true, 'both', false, 1, [canvas, container]);
    AdobeAn.compositionLoaded(lib.properties.id);

    lockScroll();
    startLoaderAnimation();
    updateFrames();
  }

  function lockScroll() {
    document.body.dataset.loaderOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }

  function unlockScroll() {
    document.body.style.overflow =
      document.body.dataset.loaderOverflow || '';
  }

  function startLoaderAnimation() {
    const loader = document.getElementById('loader_wrapper');
    const overlay = document.getElementById('overlay');

    overlay.style.opacity = 1;
    overlay.style.display = 'block';

    const tl = gsap.timeline({
      onComplete() {
        loader.remove();
        unlockScroll();
      }
    });

    tl.to(overlay, { opacity: 0, duration: 0.2 });
    tl.to(loader, {
      scale: 30,
      duration: 0.7,
      ease: 'power3.in',
      delay: 2
    });
  }

  function updateFrames() {
		if (!canvas) return;
		
    const rect = canvas.getBoundingClientRect();
    const offset = 2;

    const visibleLeft = rect.left + offset;
    const visibleTop = rect.top + offset;
    const visibleRight = rect.right - offset;
    const visibleBottom = rect.bottom - offset;

    document.querySelector('.frame.top').style.height = `${visibleTop}px`;
    document.querySelector('.frame.bottom').style.height =
      `${window.innerHeight - visibleBottom}px`;
    document.querySelector('.frame.left').style.width = `${visibleLeft}px`;
    document.querySelector('.frame.right').style.width =
      `${window.innerWidth - visibleRight}px`;
  }

  window.addEventListener('resize', updateFrames);
  window.addEventListener('orientationchange', updateFrames);

  document.addEventListener('DOMContentLoaded', initLoader);
})();

(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Topbar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AxeCjIZ4vNIJHFKMgjBAULg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.1,-81.1,224.2,162.3);


(lib.Middlebar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AxZHwUAirgUjAAGAAAIACKZI6QPOg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.4,-81.9,222.9,163.9);


(lib.Bottombar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A06JUMApygYsIADMfI/jSRg");
	this.shape.setTransform(-0.0557,-0.1275,0.8324,0.8323);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.5,-82,222.9,163.8);


// stage content:
(lib.E_loading_white_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3Au4MAAAhdvMBdvAAAMAAABdvgAmoZVIIiFDIaQvOIgCqYgA8KM5IIjFDIaQvOIgDqXUgAGAAAgiqAUigA4NvJIgDKHMAi/gULIpFlKg");
	this.shape.setTransform(300,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(34).to({_off:false},0).wait(10));

	// Top_bar
	this.instance = new lib.Topbar("synched",0);
	this.instance.setTransform(479.75,54.6);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:256.75,y:186.6,alpha:1},9,cjs.Ease.quintOut).wait(25).to({startPosition:0},0).to({alpha:0},9,cjs.Ease.none).wait(1));

	// Middle_bar
	this.instance_1 = new lib.Middlebar("synched",0);
	this.instance_1.setTransform(10.1,467.95);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).to({x:231.05,y:333,alpha:1},11,cjs.Ease.quintOut).wait(16).to({startPosition:0},0).to({alpha:0},9,cjs.Ease.none).wait(1));

	// Bottom_bar
	this.instance_2 = new lib.Bottombar("synched",0);
	this.instance_2.setTransform(591.75,281.05,1,1,0,0,0,-0.1,-0.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({x:368.75,y:412.05,alpha:1},12,cjs.Ease.quintOut).wait(6).to({startPosition:0},0).to({alpha:0},9,cjs.Ease.none).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Egu3Au4MAAAhdvMBdvAAAMAAABdvg");
	this.shape_1.setTransform(300,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).to({_off:true},34).wait(10));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(198.7,273.5,504.59999999999997,326.5);
// library properties:
lib.properties = {
	id: 'C33273F3D3424240968998591D1D8A37',
	width: 600,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['C33273F3D3424240968998591D1D8A37'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;